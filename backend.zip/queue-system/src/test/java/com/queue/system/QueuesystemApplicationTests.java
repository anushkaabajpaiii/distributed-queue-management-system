package com.queue.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QueuesystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
